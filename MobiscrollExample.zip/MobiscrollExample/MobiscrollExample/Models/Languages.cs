﻿namespace Nestle.CH.HQ.RSL.WebApp.Models
{
    public class Languages
    {
        public int Id { get; set; }
        public string? Language { get; set; }
        public string? Description { get; set; }

    }
}
