﻿namespace Nestle.CH.HQ.RSL.WebApp.Models
{
    public class CostCenter
    {
        public int? CostCenterId { get; set; }
        public string? CostCenterCode { get; set; }
        public string? CostCenterName { get; set; }
    }
}
