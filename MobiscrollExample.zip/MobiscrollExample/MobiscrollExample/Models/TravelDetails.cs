﻿namespace Nestle.CH.HQ.RSL.WebApp.Models
{
    public class TravelDetails
    {
        public string Distance { get; set; }
        public string Duration { get; set; }
        public string DurationInTraffic { get; set; }
        public string ErrorMessage { get; set; } = null;
    }
}
