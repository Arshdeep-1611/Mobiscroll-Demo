﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nestle.CH.HQ.RSL.WebApp.Models.PaymentModel
{
    public class PaymentModeType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
