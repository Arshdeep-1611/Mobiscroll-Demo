﻿namespace Nestle.CH.HQ.RSL.WebApp.Models

{
    public class ReportDashboard
    {
        public int? InternalJourneys { get; set; }
        public int? ExternalJourneys { get; set; }
        public int? OutOfPolicyJourneys { get; set; }
    }

}


