﻿namespace Nestle.CH.HQ.RSL.WebApp.Models
{
    public class Parameters
    {
        public int id { get; set; }
        public string? name { get; set; }
        public string? description { get; set; }
        public string? value { get; set; }
        public string? modified_by { get; set; }
        public DateTime time_stamp { get; set; }
    }
}
