﻿namespace Nestle.CH.HQ.RSL.WebApp.Models
{
    public class UserLink
    {
        public int UserId { get; set; } = 0;
        public int LanguageId { get; set; } = 0;
        public string UserType { get; set; } = string.Empty;
    }
}
