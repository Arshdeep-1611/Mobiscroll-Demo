﻿namespace Nestle.CH.HQ.RSL.WebApp.Models
{
    public class PredefinedTrip
    {
        public int? TripId { get; set; }
        public string? PredefinedTripName { get; set; }
        public int? FlightType { get; set; }
    }
}
