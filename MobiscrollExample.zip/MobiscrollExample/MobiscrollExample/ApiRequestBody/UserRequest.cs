﻿namespace Nestle.CH.HQ.RSL.WebApp.ApiRequestBody
{
    public class UserRequest
    {
        public string AccessToken { get; set; } = string.Empty;
    }
}
